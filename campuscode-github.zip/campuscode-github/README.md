# Campus Code Kuwait

Kuwait's first university merchandise supply partner.

## Deployment

This site is deployed via GitHub Pages.

- **Live URL:** https://[your-username].github.io/campuscode/
- **Custom Domain:** campuscode.kw

## Files

- `index.html` — Full single-file website (all pages, blog, and assets embedded)
